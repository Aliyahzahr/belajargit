package com.example.tourism_place

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
