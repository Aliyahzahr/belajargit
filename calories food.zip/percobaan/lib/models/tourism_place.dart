class TourismPlace {
  String name;
  String description;
  String grams;
  String calories;
  String imagesAsset;
  List<String> imageUrls;

  TourismPlace({
    required this.name,
    required this.description,
    required this.grams,
    required this.calories,
    required this.imagesAsset,
    required this.imageUrls,
  });
}

var tourismPlaceList = [
  TourismPlace(
    name: 'Dada Ayam',
    description:
        'Dada ayam menjadi salah satu favorit makanan diet. Ini karena dada ayam merupakan daging tanpa lemak yang juga rendah kalori, tapi tinggi protein. Dada ayam juga mengandung niasin, selenium, hingga vitamin B12 yang tentu saja sangat baik bagi kesehatan tubuh.',
    grams: '85g',
    calories: '100cal',
    imagesAsset: 'images/dada.jpeg',
    imageUrls: [
      'https://i.pinimg.com/564x/4c/1c/00/4c1c00c86f8f775a9c32edc8faa0ed7d.jpg',
      'https://i.pinimg.com/564x/92/43/91/924391d3f9f2afeee2bd64a61d3eb501.jpg',
      'https://i.pinimg.com/236x/b0/fc/16/b0fc166b4f452ed1ad8f0f8834a6710b.jpg'
    ],
  ),
  TourismPlace(
    name: 'Telur',
    description:
        'Telur juga termasuk salah satu makanan berprotein tinggi yang mengenyangkan sehingga bisa mengurangi rasa lapar. Namun, jika sedang diet, sebaiknya konsumsi telur dengan cara direbus untuk menghindari kandungan lemak tak sehat dari minyak goreng.',
    grams: '6g',
    calories: '72cal',
    imagesAsset: 'images/telur.jpg',
    imageUrls: [
      'https://i.pinimg.com/564x/ae/aa/cf/aeaacfeb57ce76475f5984a4b9ce7c3a.jpg',
      'https://i.pinimg.com/564x/23/49/95/234995bde32e1eceec4d9fa5b76f9da1.jpg',
      'https://i.pinimg.com/564x/23/49/95/234995bde32e1eceec4d9fa5b76f9da1.jpg',
    ],
  ),
  TourismPlace(
    name: 'Udang',
    description:
        'Udang merupakan sumber protein hewani yang rendah lemak dan rendah kalori. Oleh karena itu, cocok untuk diet yang membatasi asupan kalori Penting untuk memperhatikan cara udang dimasak dan disajikan. Untuk mendapatkan manfaat maksimal dari diet Anda, hindari penggunaan minyak dan saus berlebihan yang tinggi gula dan garam.',
    grams: '100g',
    calories: '144cal',
    imagesAsset: 'images/udang.jpg',
    imageUrls: [
      'https://i.pinimg.com/564x/13/7d/1e/137d1e3d266acaeca2f8f83bb62ff849.jpg',
      'https://i.pinimg.com/564x/12/da/05/12da05674034f499f4415045b8ecd22e.jpg',
      'https://i.pinimg.com/564x/68/b1/1c/68b11c80331b5928a001507d5b26162e.jpg',
    ],
  ),
  TourismPlace(
    name: 'Bayam',
    description:
        'Bayam merupakan salah satu pilihan sayuran rendah kalori, Sayuran ini cocok menjadi menu diet yang sehat karena diperkaya dengan beta karoten yang penting untuk menurunkan berat badan dan tinggi akan zat besi yang berguna untuk mencegah anemia. Bayam juga memiliki tekstur yang lembut, sehingga nikmat disantap sebagai sup bayam.Perlu diingat bahwa keberhasilan diet tidak hanya dipengaruhi oleh pilihan makanan rendah kalori untuk diet, tetapi juga didukung dengan intensitas berolahraga. Olahraga secara rutin akan membantu pembentukan otot tubuh, sehingga Anda bisa menurunkan berat badan dengan cara yang sehat.',
    grams: '100g',
    calories: '16cal',
    imagesAsset: 'images/bayam.jpg',
    imageUrls: [
      'https://i.pinimg.com/564x/23/49/95/234995bde32e1eceec4d9fa5b76f9da1.jpg',
      'https://i.pinimg.com/564x/d3/31/ca/d331ca8582f2faa20f0315baf0fd22a9.jpg',
      'https://i.pinimg.com/564x/86/08/1c/86081cd9d6a15a2439e0a94a0f46ff6c.jpg',
    ],
  ),
  TourismPlace(
    name: 'Brokoli',
    description:
        'brokoli biasanya menjadi teman dada ayam yang dikonsumsi para pejuang diet. Wajar saja, pasalnya brokoli berserat tinggi dengan kalori rendah. Brokoli juga mengandung vitamin C, vitamin A, zat besi, magnesium, kalsium, dan kalium yang baik untuk kesehatan tubuh.',
    grams: '100g',
    calories: '34cal',
    imagesAsset: 'images/brokoli.jpg',
    imageUrls: [
      'https://i.pinimg.com/564x/34/10/c6/3410c66c9d81243fb14de0e8dd33b2be.jpg',
      'https://i.pinimg.com/564x/28/d3/49/28d3492c1dc29b08d82ae96eff7495f8.jpg',
      'https://i.pinimg.com/564x/a0/9e/e9/a09ee94ca65e36239c04020152f91b82.jpg',
    ],
  ),
  TourismPlace(
    name: 'Kentang',
    description:
        'Kentang dapat dimasak dengan berbagai cara, seperti direbus, dipanggang, atau dikukus. Ini memungkinkan Anda untuk menciptakan hidangan kentang yang berbeda setiap hari, menjaga keberagaman dalam diet Anda. Untuk diet seimbang, pastikan untuk memadukan kentang dengan protein sehat, seperti ayam tanpa kulit, ikan, atau kacang-kacangan, serta sayuran berdaun hijau atau sayuran lainnya.',
    grams: '100g',
    calories: '144cal',
    imagesAsset: 'images/kentang.jpg',
    imageUrls: [
      'https://i.pinimg.com/564x/82/f7/36/82f736662b1f3e26e843f02a5175ea33.jpg',
      'https://i.pinimg.com/564x/b5/e3/c9/b5e3c906ea82218a6799315bc32a0839.jpg',
      'https://i.pinimg.com/564x/3f/73/9a/3f739aa65148a55a71dd71df7d89072c.jpg',
    ],
  ),
  TourismPlace(
    name: 'Selada Romaine',
    description:
        'Selada mengandung serat dan rendah kalori sehingga cocok untuk membantu menurunkan serta mengontrol berat badan, Nutrisi dalam selada romaine memberikan banyak manfaat kesehatan: Vitamin C membantu mendukung sistem kekebalan tubuh, tinggi antioksidan , dan membantu menjaga tulang dan gigi tetap kuat',
    grams: '100g',
    calories: '17,2cal',
    imagesAsset: 'images/selada.jpg',
    imageUrls: [
      'https://i.pinimg.com/564x/8a/58/4d/8a584d5d2a6bf5f2d69023f8ee195764.jpg',
      'https://i.pinimg.com/564x/56/f8/56/56f85668ca50748a1f863f07e8c8b0b0.jpg',
      'https://i.pinimg.com/564x/56/f8/56/56f85668ca50748a1f863f07e8c8b0b0.jpg',
    ],
  ),
  TourismPlace(
    name: 'Alpukat',
    description:
        'Alpukat mengandung sejumlah nutrisi penting seperti vitamin K, vitamin E, vitamin C, kalium, dan sebagainya. Diet dengan alpukat memanfaatkan kandungan nutrisi ini untuk memberikan dukungan yang baik bagi kesehatan secara keseluruhan. Beberapa varian diet dengan alpukat menggunakan buah ini sebagai pengganti makanan tinggi karbohidrat, seperti roti atau nasi. Ini dapat membantu dalam mengontrol kadar gula darah dan menurunkan asupan karbohidrat yang sederhana.',
    grams: '100g',
    calories: '160cal',
    imagesAsset: 'images/alpukat.png',
    imageUrls: [
      'https://i.pinimg.com/564x/56/f8/56/56f85668ca50748a1f863f07e8c8b0b0.jpg',
      'https://i.pinimg.com/564x/10/e4/98/10e4980b5bf4e5ca192cbdd7656f0dde.jpg',
      'https://i.pinimg.com/564x/a6/84/5b/a6845b83884f09cdee534c47df490672.jpg',
    ],
  ),
  TourismPlace(
    name: 'Apel',
    description:
        'apel mengandung senyawa pektin yang tinggi, yaitu serat larut yang dapat memberikan efek kenyang lebih lama sehingga bisa membantu mengendalikan nafsu makan saat sedang diet, Makan satu atau dua apel sebagai camilan malam bisa membantu kamu tetap kenyang tanpa takut gemuk.',
    grams: '100g',
    calories: '52,1cal',
    imagesAsset: 'images/apel.png',
    imageUrls: [
      'https://i.pinimg.com/564x/89/76/c7/8976c7609611a4866d75d1bfd0ac00f8.jpg',
      'https://i.pinimg.com/564x/fc/92/0d/fc920d5b3efcde33dbe45b183b746a8a.jpg',
      'https://i.pinimg.com/564x/32/ea/9d/32ea9d5d9cbb98ba3dfe0d066afbf29e.jpg',
    ],
  ),
];
